"""Verification: source totals, tie-outs, allocation limits and re-validation by the reference engine."""
from __future__ import annotations
from collections import defaultdict
from dataclasses import dataclass
from decimal import Decimal
from fractions import Fraction
from . import reference as ref
from .analysis import AnalysisResult, plan_dict
from .ingest import Table
from .recon import BUCKETS, ReconResult


@dataclass
class Check:
    name: str
    ok: bool
    detail: str = ""
    critical: bool = True


@dataclass
class Certification:
    status: str          # verified | unverified | refused
    checks: list[Check]


def _status(checks):
    if all(c.ok for c in checks):
        return "verified"
    return "refused" if any(not c.ok and c.critical for c in checks) else "unverified"


def _excluded(t: Table) -> bool:
    return t.totals_row is not None and (not t.rows or t.rows[-1] is not t.totals_row)


def verify_analysis(res: AnalysisResult, t: Table) -> Certification:
    ex = _excluded(t)
    checks = []
    src = ref.column_total(t.path, res.plan.amount, ex)
    checks.append(Check("Source total (read from original file) equals engine total", src == Fraction(res.total), f"{src} vs {res.total}"))
    if res.plan.kind != "total":
        g = ref.group_totals(t.path, res.plan.amount, res.plan.group, res.plan.kind == "monthly", ex)
        ok = all(g.get(k) == Fraction(v) for k, v in res.rows)
        checks.append(Check("Independent recomputation reproduces every shown row", ok))
    if res.rows_skipped:
        checks.append(Check("Rows with unreadable values", False, f"{res.rows_skipped} skipped", critical=False))
    return Certification(_status(checks), checks)


def verify_recon(res: ReconResult, lt: Table, rt: Table) -> Certification:
    st, checks = res.strategy, []
    for side, t, col, rows in (("Left", lt, st.left_amount, res.left), ("Right", rt, st.right_amount, res.right)):
        src = ref.column_total(t.path, col, _excluded(t))
        checks.append(Check(f"{side} source total equals engine total", src == Fraction(sum((r.amount for r in rows), Decimal(0))), str(src)))
    n = len(res.left) + len(res.right)
    checks.append(Check("Every row is in exactly one bucket", len(res.bucket) == n and set(res.bucket.values()) <= set(BUCKETS), f"{len(res.bucket)} of {n}"))
    for side, name in (("L", "Left"), ("R", "Right")):
        t_out = res.tieout(side)
        checks.append(Check(f"{name} tie-out: total equals sum of buckets", sum((v[1] for v in t_out.values()), Decimal(0)) == res.total(side)))
    used = defaultdict(Decimal)
    for a in res.allocs:
        used[("L", a.left)] += a.amount
        used[("R", a.right)] += a.amount
    cap = {("L", r.idx): abs(r.amount) for r in res.left} | {("R", r.idx): abs(r.amount) for r in res.right}
    checks.append(Check("No row is allocated beyond its amount", all(used[k] <= cap[k] for k in used)))
    full = [k for k, b in res.bucket.items() if b in ("matched", "matched_amount_date", "split")]
    checks.append(Check("Matched and split rows are fully allocated (within tolerance)", all(cap[k] - used[k] <= st.tolerance for k in full)))
    lv = ref.row_values(lt.path, st.left_key, st.left_amount, _excluded(lt))
    rv = ref.row_values(rt.path, st.right_key, st.right_amount, _excluded(rt))
    byg = defaultdict(list)
    for a in res.allocs:
        byg[a.group].append(a)
    gmeta = {g["id"]: g for g in res.groups}
    ok = True
    for gid, al in byg.items():
        if sum(a.amount for a in al) <= 0:
            ok = False
        for a in al:
            lk, la = lv[a.left]
            rk, ra = rv[a.right]
            if la is None or ra is None or Fraction(a.amount) > abs(la) or Fraction(a.amount) > abs(ra):
                ok = False
            if gmeta[gid]["pass"] != "amount_date" and lk != rk:
                ok = False
    checks.append(Check("Reference engine re-validates every allocation from the original files", ok, f"{len(res.allocs)} allocations"))
    return Certification(_status(checks), checks)
