from .cli import main
main(["demo"])
