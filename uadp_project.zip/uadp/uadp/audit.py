"""Hash-chained audit log: each event stores the hash of the previous one."""
from __future__ import annotations
import hashlib, json, time
from dataclasses import dataclass, field


def _h(prev: str, ts: float, kind: str, detail: dict) -> str:
    body = json.dumps([prev, ts, kind, detail], sort_keys=True, default=str)
    return hashlib.sha256(body.encode()).hexdigest()


@dataclass
class AuditLog:
    events: list[dict] = field(default_factory=list)

    def add(self, kind: str, **detail) -> dict:
        prev = self.events[-1]["hash"] if self.events else "0" * 64
        ts = time.time()
        ev = {"ts": ts, "kind": kind, "detail": detail, "prev": prev, "hash": _h(prev, ts, kind, detail)}
        self.events.append(ev)
        return ev

    def verify(self) -> bool:
        prev = "0" * 64
        for ev in self.events:
            if ev["prev"] != prev or ev["hash"] != _h(prev, ev["ts"], ev["kind"], ev["detail"]):
                return False
            prev = ev["hash"]
        return True
