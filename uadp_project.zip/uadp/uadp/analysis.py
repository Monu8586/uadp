"""Typed analysis plans evaluated deterministically. The AI (later) may only propose a plan object."""
from __future__ import annotations
from collections import defaultdict
from dataclasses import dataclass, asdict
from decimal import Decimal
from .ingest import Table, parse_date
from .money import parse_amount


class PlanError(Exception):
    pass


@dataclass(frozen=True)
class AnalysisPlan:
    kind: str            # "total" | "group_total" | "monthly"
    amount: str
    group: str | None = None
    top_n: int = 10
    schema_version: int = 1


@dataclass
class AnalysisResult:
    plan: AnalysisPlan
    rows: list[tuple[str, Decimal]]
    total: Decimal
    rows_used: int
    rows_skipped: int
    ties_hidden: int = 0


def validate(plan: AnalysisPlan, t: Table) -> None:
    if not t.confirmed:
        raise PlanError("Confirm column types and roles before asking questions.")
    if plan.kind not in {"total", "group_total", "monthly"}:
        raise PlanError(f"I can't compute '{plan.kind}' yet. Supported: total, group_total, monthly.")
    for name in [plan.amount] + ([plan.group] if plan.kind != "total" else []):
        if name not in t.headers:
            raise PlanError(f"Unknown column {name!r}.")
    if next(c for c in t.columns if c.name == plan.amount).type != "number":
        raise PlanError(f"{plan.amount!r} is not a number column.")
    if not 1 <= plan.top_n <= 1000:
        raise PlanError("top_n must be between 1 and 1000.")


def run(plan: AnalysisPlan, t: Table) -> AnalysisResult:
    validate(plan, t)
    ai = t.index(plan.amount)
    gi = t.index(plan.group) if plan.kind != "total" else None
    groups: dict[str, Decimal] = defaultdict(Decimal)
    used = skipped = 0
    for r in t.rows:
        a = parse_amount(r[ai]) if ai < len(r) else None
        if a is None:
            skipped += 1
            continue
        if plan.kind == "total":
            k = "All rows"
        elif plan.kind == "monthly":
            d = parse_date(r[gi])
            if d is None:
                skipped += 1
                continue
            k = d.strftime("%Y-%m")
        else:
            k = (r[gi].strip() or "(blank)")
        groups[k] += a
        used += 1
    total = sum(groups.values(), Decimal(0))
    rows = sorted(groups.items(), key=(lambda x: x[0]) if plan.kind == "monthly" else (lambda x: (-x[1], x[0])))
    hidden = 0
    if plan.kind == "group_total" and len(rows) > plan.top_n:
        cut = rows[plan.top_n - 1][1]
        hidden = sum(1 for _, v in rows[plan.top_n:] if v == cut)
        rows = rows[:plan.top_n]
    return AnalysisResult(plan, rows, total, used, skipped, hidden)


def plan_dict(plan: AnalysisPlan) -> dict:
    return asdict(plan)
