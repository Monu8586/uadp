"""Independent reference engine.

Written separately from the production path: it reads original files itself and uses Fraction
arithmetic. It must NOT import ingest, money, analysis or recon (a test enforces this).
"""
import csv, io, re, string
from collections import defaultdict
from fractions import Fraction

_ALNUM = set(string.ascii_uppercase + string.digits)


def _text(path):
    raw = open(path, "rb").read()
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return raw.decode("utf-16")
    try:
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        return raw.decode("cp1252")


def ref_amount(s):
    t = (s or "").strip()
    for junk in ("₹", ",", "INR", "Rs.", "Rs", " "):
        t = t.replace(junk, "")
    if not t:
        return None
    sign = 1
    if t.startswith("(") and t.endswith(")"):
        sign, t = -1, t[1:-1]
    if t.endswith("-"):
        sign, t = -sign, t[:-1]
    if t[:1] == "-":
        sign, t = -sign, t[1:]
    elif t[:1] == "+":
        t = t[1:]
    if not t or t == "." or t.count(".") > 1 or any(c not in "0123456789." for c in t):
        return None
    return sign * Fraction(t)


def ref_norm(s):
    return "".join(c for c in str(s or "").upper() if c in _ALNUM)


def read_file(path, exclude_totals=False):
    """Return (headers, body_rows)."""
    text = _text(path)
    lines = [l for l in text.splitlines() if l.strip()]
    delim = max(",;\t|", key=lambda d: (sum(len(l.split(d)) > 1 for l in lines[:20]), len(lines[0].split(d))))
    rows = [r for r in csv.reader(io.StringIO(text), delimiter=delim) if any(c.strip() for c in r)]
    widths = defaultdict(int)
    for r in rows[:30]:
        widths[len(r)] += 1
    mode = max(widths, key=lambda w: (widths[w], -w))
    h = 0
    for i, r in enumerate(rows[:30]):
        if len(r) == mode and all(ref_amount(c) is None for c in r):
            h = i
            break
    headers = [c.strip() for c in rows[h]]
    body = rows[h + 1:]
    if exclude_totals and body and re.match(r"(?i)^\s*(grand\s+)?total", body[-1][0]):
        body = body[:-1]
    return headers, body


def column_total(path, column, exclude_totals=False):
    headers, body = read_file(path, exclude_totals)
    j = headers.index(column)
    total = Fraction(0)
    for r in body:
        v = ref_amount(r[j]) if j < len(r) else None
        if v is not None:
            total += v
    return total


def group_totals(path, amount_col, group_col, monthly=False, exclude_totals=False):
    headers, body = read_file(path, exclude_totals)
    a, g = headers.index(amount_col), headers.index(group_col)
    out = defaultdict(Fraction)
    for r in body:
        v = ref_amount(r[a]) if a < len(r) else None
        if v is None:
            continue
        key = r[g].strip() or "(blank)"
        if monthly:
            m = re.match(r"^(\d{4})-(\d{2})-\d{2}", key)
            if m:
                key = f"{m[1]}-{m[2]}"
            else:
                m = re.match(r"^(\d{1,2})[-/](\d{1,2})[-/](\d{4})", key)
                if not m:
                    continue
                key = f"{m[3]}-{int(m[2]):02d}"
        out[key] += v
    return dict(out)


def row_values(path, key_col, amount_col, exclude_totals=False):
    """List of (normalized key, amount) in data-row order, for recon re-validation."""
    headers, body = read_file(path, exclude_totals)
    k, a = headers.index(key_col), headers.index(amount_col)
    return [(ref_norm(r[k]) if k < len(r) else "", ref_amount(r[a]) if a < len(r) else None) for r in body]
