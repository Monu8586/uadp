"""Universal AI Data Platform core (v0.1 prototype). Money is Decimal, never float."""
__version__ = "0.1.0"
