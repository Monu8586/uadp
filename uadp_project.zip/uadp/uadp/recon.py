"""Universal reconciliation engine: strategy + passes + allocation ledger + buckets."""
from __future__ import annotations
import re
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from .ingest import Table, parse_date
from .money import parse_amount

BUCKETS = ("matched", "matched_amount_date", "matched_diff", "split", "ambiguous", "unmatched")


class OverAllocation(Exception):
    pass


class ReconError(Exception):
    pass


@dataclass(frozen=True)
class Strategy:
    name: str
    left_key: str
    left_amount: str
    left_date: str
    right_key: str
    right_amount: str
    right_date: str
    tolerance: Decimal = Decimal(0)
    date_window: int = 2
    version: int = 1


@dataclass
class Row:
    idx: int
    key: str
    amount: Decimal
    day: date | None


@dataclass
class Alloc:
    group: int
    left: int
    right: int
    amount: Decimal


def norm_key(s) -> str:
    return re.sub(r"[^A-Z0-9]", "", str(s or "").upper())


class Ledger:
    """Allocation ledger: a row can be split across groups but never beyond its amount."""

    def __init__(self, left: list[Row], right: list[Row]):
        self.cap = {("L", r.idx): abs(r.amount) for r in left} | {("R", r.idx): abs(r.amount) for r in right}
        self.used: dict = defaultdict(Decimal)
        self.allocs: list[Alloc] = []

    def allocate(self, group: int, l: Row, r: Row, amount: Decimal) -> None:
        if amount <= 0:
            raise OverAllocation("Allocation must be positive.")
        if (l.amount < 0) != (r.amount < 0):
            raise OverAllocation("Allocation would flip a sign.")
        for side, row in (("L", l), ("R", r)):
            k = (side, row.idx)
            if self.used[k] + amount > self.cap[k]:
                raise OverAllocation(f"{side}{row.idx} would be allocated beyond its amount.")
        for side, row in (("L", l), ("R", r)):
            self.used[(side, row.idx)] += amount
        self.allocs.append(Alloc(group, l.idx, r.idx, amount))


@dataclass
class ReconResult:
    strategy: Strategy
    left: list[Row]
    right: list[Row]
    bucket: dict            # (side, idx) -> bucket
    groups: list[dict]
    allocs: list[Alloc]

    def total(self, side: str) -> Decimal:
        return sum((r.amount for r in (self.left if side == "L" else self.right)), Decimal(0))

    def tieout(self, side: str) -> dict:
        out = {b: [0, Decimal(0)] for b in BUCKETS}
        for r in (self.left if side == "L" else self.right):
            b = self.bucket[(side, r.idx)]
            out[b][0] += 1
            out[b][1] += r.amount
        return {b: tuple(v) for b, v in out.items()}


def _rows(t: Table, key: str, amount: str, dt: str) -> list[Row]:
    if not t.confirmed:
        raise ReconError(f"Confirm column roles on {t.name} first.")
    ki, ai, di = t.index(key), t.index(amount), t.index(dt)
    out = []
    for i, r in enumerate(t.rows):
        a = parse_amount(r[ai]) if ai < len(r) else None
        if a is None:
            raise ReconError(f"RECON_INVALID_AMOUNT: {t.name} row {i + 1} has an unreadable amount.")
        out.append(Row(i, norm_key(r[ki]) if ki < len(r) else "", a, parse_date(r[di]) if di < len(r) else None))
    return out


def reconcile(lt: Table, rt: Table, st: Strategy) -> ReconResult:
    L = _rows(lt, st.left_key, st.left_amount, st.left_date)
    R = _rows(rt, st.right_key, st.right_amount, st.right_date)
    ledger, bucket, groups = Ledger(L, R), {}, []
    tol = st.tolerance

    def mark(rows_l, rows_r, b):
        for x in rows_l:
            bucket[("L", x.idx)] = b
        for x in rows_r:
            bucket[("R", x.idx)] = b

    lk, rk = defaultdict(list), defaultdict(list)
    for x in L:
        if x.key:
            lk[x.key].append(x)
    for x in R:
        if x.key:
            rk[x.key].append(x)
    # Pass 1: shared key. One-to-one, or grouped split when sums agree.
    for key in sorted(lk.keys() & rk.keys()):
        ls, rs = lk[key], rk[key]
        if len({x.amount < 0 for x in ls + rs}) > 1:
            mark(ls, rs, "ambiguous")
            continue
        sl, sr = sum(abs(x.amount) for x in ls), sum(abs(x.amount) for x in rs)
        gid = len(groups)
        if len(ls) == 1 and len(rs) == 1:
            if min(sl, sr) > 0:
                ledger.allocate(gid, ls[0], rs[0], min(sl, sr))
            mark(ls, rs, "matched" if abs(sl - sr) <= tol else "matched_diff")
            groups.append({"id": gid, "pass": "exact_key", "key": key})
        elif abs(sl - sr) <= tol:
            remL = {x.idx: abs(x.amount) for x in ls}
            remR = {x.idx: abs(x.amount) for x in rs}
            i = j = 0
            while i < len(ls) and j < len(rs):
                a = min(remL[ls[i].idx], remR[rs[j].idx])
                if a > 0:
                    ledger.allocate(gid, ls[i], rs[j], a)
                    remL[ls[i].idx] -= a
                    remR[rs[j].idx] -= a
                if remL[ls[i].idx] == 0:
                    i += 1
                elif remR[rs[j].idx] == 0:
                    j += 1
            mark(ls, rs, "split")
            groups.append({"id": gid, "pass": "grouped_key", "key": key})
        else:
            mark(ls, rs, "ambiguous")
    # Pass 2: amount within tolerance and date within window, only if mutually unique.
    rl = [x for x in L if ("L", x.idx) not in bucket]
    rr = [x for x in R if ("R", x.idx) not in bucket]

    def near(l: Row, r: Row) -> bool:
        return l.day is not None and r.day is not None and abs(l.amount - r.amount) <= tol and abs((l.day - r.day).days) <= st.date_window

    cl = {l.idx: [r for r in rr if near(l, r)] for l in rl}
    cr = {r.idx: [l for l in rl if near(l, r)] for r in rr}
    for l in rl:
        c = cl[l.idx]
        if len(c) == 1 and len(cr[c[0].idx]) == 1:
            gid = len(groups)
            if abs(l.amount) > 0:
                ledger.allocate(gid, l, c[0], min(abs(l.amount), abs(c[0].amount)))
            mark([l], [c[0]], "matched_amount_date")
            groups.append({"id": gid, "pass": "amount_date", "key": None})
    for l in rl:
        if ("L", l.idx) not in bucket and cl[l.idx]:
            bucket[("L", l.idx)] = "ambiguous"
    for r in rr:
        if ("R", r.idx) not in bucket and cr[r.idx]:
            bucket[("R", r.idx)] = "ambiguous"
    for x in L:
        bucket.setdefault(("L", x.idx), "unmatched")
    for x in R:
        bucket.setdefault(("R", x.idx), "unmatched")
    return ReconResult(st, L, R, bucket, groups, ledger.allocs)


def detect_strategy(lt: Table, rt: Table) -> list[tuple[str, float, str]]:
    """Rank strategies from column names. The user must still confirm; nothing runs automatically."""
    def has(t, rx):
        return any(re.search(rx, h, re.I) for h in t.headers)
    pg = 0.4 * has(lt, r"utr|payout|settle") + 0.3 * has(lt, r"net|settle") + 0.3 * has(rt, r"credit|debit|value_date|bank")
    inv = 0.5 * has(lt, r"invoice") + 0.5 * has(rt, r"payment|receipt")
    ranked = sorted([("pg_vs_bank", round(pg, 2), "left looks like a payout report; right looks like a bank statement"),
                     ("invoice_vs_payment", round(inv, 2), "left has invoices; right has payments or receipts"),
                     ("custom", 0.2, "define keys and tolerances yourself")], key=lambda x: -x[1])
    return ranked


def preselect(ranked) -> str | None:
    return ranked[0][0] if ranked[0][1] >= 0.7 and ranked[0][1] - ranked[1][1] >= 0.1 else None
