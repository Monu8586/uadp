"""Command line: uadp profile | ask | recon | demo."""
from __future__ import annotations
import argparse, json, sys, tempfile
from decimal import Decimal
from pathlib import Path
from .analysis import AnalysisPlan, PlanError, plan_dict, run
from .audit import AuditLog
from .evidence import build_evidence
from .ingest import IngestError, confirm, read_table
from .money import format_inr
from .recon import BUCKETS, ReconError, Strategy, detect_strategy, preselect, reconcile
from .verify import verify_analysis, verify_recon

LOG = AuditLog()


def _load(path, auth):
    t = read_table(path, auth)
    LOG.add("upload", file=t.name, sha256=t.sha256, authorization=t.authorization)
    confirm(t)
    LOG.add("confirm_roles", file=t.name)
    return t


def _show(cert):
    for c in cert.checks:
        print(f"  [{'pass' if c.ok else 'FAIL'}] {c.name}" + (f"  ({c.detail})" if c.detail else ""))
    print(f"Status: {cert.status.upper()}")


def cmd_profile(a):
    t = _load(a.file, a.auth)
    print(f"{t.name}: {len(t.rows)} rows, {len(t.headers)} columns, sha256 {t.sha256[:16]}…, {t.encoding}, delimiter {t.delimiter!r}")
    for c in t.columns:
        extra = format_inr(c.total) if c.total is not None else (f"{c.min} to {c.max}" if c.min else "")
        print(f"  {c.name:<18}{c.type:<7}role={c.role:<9}empty={c.nulls:<4}distinct={c.distinct:<5}{extra}")
    for w in t.warnings:
        print("  warning:", w)


def cmd_ask(a):
    t = _load(a.file, a.auth)
    plan = AnalysisPlan(a.kind, a.amount, a.group, a.top)
    try:
        res = run(plan, t)
    except PlanError as e:
        sys.exit(f"Cannot run: {e}")
    cert = verify_analysis(res, t)
    LOG.add("analysis", plan=plan_dict(plan), status=cert.status)
    if cert.status == "refused":
        print("Refused: a critical check failed, so no numbers are shown.")
    else:
        for k, v in res.rows:
            print(f"  {k:<20}{format_inr(v):>18}")
        print(f"  Total {format_inr(res.total)} over {res.rows_used} rows" + (f" ({res.ties_hidden} tied rows hidden)" if res.ties_hidden else ""))
    _show(cert)


def cmd_recon(a):
    lt, rt = _load(a.left, a.auth), _load(a.right, a.auth)
    ranked = detect_strategy(lt, rt)
    print("Suggested strategies:", "; ".join(f"{n} {s}" for n, s, _ in ranked), "| preselected:", preselect(ranked))
    st = Strategy(a.strategy, a.lk, a.la, a.ld, a.rk, a.ra, a.rd, Decimal(a.tol), a.window)
    try:
        res = reconcile(lt, rt, st)
    except ReconError as e:
        sys.exit(f"Cannot run: {e}")
    cert = verify_recon(res, lt, rt)
    LOG.add("reconcile", strategy=st.name, status=cert.status)
    if cert.status != "refused":
        for side, name in (("L", "Left"), ("R", "Right")):
            parts = " + ".join(f"{b} {format_inr(v[1])}" for b, v in res.tieout(side).items() if v[0])
            print(f"{name} total {format_inr(res.total(side))} = {parts}")
    _show(cert)
    if a.evidence and cert.status != "refused":
        h = build_evidence(a.evidence, {"result.json": json.dumps({b: [res.tieout("L")[b][0], str(res.tieout("L")[b][1])] for b in BUCKETS}),
                                       "checks.json": json.dumps([c.__dict__ for c in cert.checks]),
                                       "provenance.json": json.dumps({lt.name: lt.sha256, rt.name: rt.sha256}),
                                       "audit.json": json.dumps(LOG.events)})
        print("Evidence written:", a.evidence, "sha256", h[:16] + "…")


def cmd_demo(a):
    from .synthetic import write_sample
    d = Path(a.out or tempfile.mkdtemp(prefix="uadp_demo_"))
    f = write_sample(d)
    print("Synthetic files in", d)
    cmd_ask(argparse.Namespace(file=f["sales.csv"], auth="Synthetic", kind="group_total", amount="gross_amount", group="category", top=10))
    cmd_recon(argparse.Namespace(left=f["pg.csv"], right=f["bank.csv"], auth="Synthetic", strategy="pg_vs_bank", lk="payout_utr", la="net_amount", ld="settlement_date",
                                 rk="bank_ref", ra="credit", rd="value_date", tol="0", window=2, evidence=str(d / "evidence.zip")))
    print("Audit chain valid:", LOG.verify())


def main(argv=None):
    p = argparse.ArgumentParser(prog="uadp")
    s = p.add_subparsers(dest="cmd", required=True)
    x = s.add_parser("profile"); x.add_argument("file"); x.add_argument("--auth", required=True); x.set_defaults(f=cmd_profile)
    x = s.add_parser("ask"); x.add_argument("file"); x.add_argument("--auth", required=True)
    x.add_argument("--kind", choices=["total", "group_total", "monthly"], default="group_total"); x.add_argument("--amount", required=True)
    x.add_argument("--group"); x.add_argument("--top", type=int, default=10); x.set_defaults(f=cmd_ask)
    x = s.add_parser("recon"); x.add_argument("left"); x.add_argument("right"); x.add_argument("--auth", required=True)
    for n in ("lk", "la", "ld", "rk", "ra", "rd"):
        x.add_argument("--" + n, required=True)
    x.add_argument("--strategy", default="custom"); x.add_argument("--tol", default="0"); x.add_argument("--window", type=int, default=2)
    x.add_argument("--evidence"); x.set_defaults(f=cmd_recon)
    x = s.add_parser("demo"); x.add_argument("--out"); x.set_defaults(f=cmd_demo)
    a = p.parse_args(argv)
    try:
        a.f(a)
    except IngestError as e:
        sys.exit(str(e))


if __name__ == "__main__":
    main()
