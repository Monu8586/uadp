"""Money parsing and Indian number formatting (Decimal only)."""
from __future__ import annotations
import re
from decimal import Decimal, ROUND_HALF_EVEN

_STRIP = re.compile(r"[₹,\s]|INR|Rs\.?", re.I)
_NUM = re.compile(r"\d+(\.\d+)?|\.\d+")
CENT = Decimal("0.01")


def parse_amount(value) -> Decimal | None:
    """Parse '₹1,23,456.50', '(500)', '500-', '-12.5'. Returns None if unreadable.
    Scientific notation (1E+5) is rejected on purpose: it usually means a damaged ID or amount."""
    if value is None:
        return None
    t = str(value).strip()
    if not t:
        return None
    neg = False
    if t.startswith("(") and t.endswith(")"):
        neg, t = True, t[1:-1]
    t = _STRIP.sub("", t)
    if t.endswith("-"):
        neg, t = not neg, t[:-1]
    if t.startswith("-"):
        neg, t = not neg, t[1:]
    elif t.startswith("+"):
        t = t[1:]
    if not _NUM.fullmatch(t):
        return None
    d = Decimal(t)
    return -d if neg else d


def q2(d: Decimal) -> Decimal:
    return d.quantize(CENT, rounding=ROUND_HALF_EVEN)


def format_inr(d: Decimal) -> str:
    d = q2(d)
    sign = "-" if d < 0 else ""
    whole, frac = f"{abs(d):.2f}".split(".")
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        whole = ",".join(parts + [tail])
    return f"{sign}₹{whole}.{frac}"
