"""Ingestion and profiling: encoding, delimiter, header row, totals row, hash, warnings, role hints."""
from __future__ import annotations
import csv, hashlib, io, re
from collections import Counter
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from pathlib import Path
from .money import parse_amount

MAX_BYTES_DEFAULT = 100 * 1024 * 1024
EXCEL_LIMITS = (1_048_576, 65_536)


class IngestError(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(f"{code}: {message}")
        self.code = code


def parse_date(s) -> date | None:
    t = str(s or "").strip()
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})", t)
    try:
        if m:
            return date(int(m[1]), int(m[2]), int(m[3]))
        m = re.match(r"^(\d{1,2})[-/](\d{1,2})[-/](\d{4})", t)
        return date(int(m[3]), int(m[2]), int(m[1])) if m else None
    except ValueError:
        return None


@dataclass
class Column:
    name: str
    type: str
    nulls: int
    distinct: int
    total: Decimal | None = None
    negatives: int = 0
    min: str | None = None
    max: str | None = None
    role: str = "other"
    confidence: float = 0.5


@dataclass
class Table:
    name: str
    path: str
    sha256: str
    encoding: str
    delimiter: str
    headers: list[str]
    rows: list[list[str]]
    authorization: str
    warnings: list[dict] = field(default_factory=list)
    totals_row: list[str] | None = None
    columns: list[Column] = field(default_factory=list)
    confirmed: bool = False

    def index(self, name: str) -> int:
        try:
            return self.headers.index(name)
        except ValueError:
            raise KeyError(f"No column named {name!r}. Columns: {', '.join(self.headers)}")

    def col(self, name: str) -> list[str]:
        i = self.index(name)
        return [r[i] if i < len(r) else "" for r in self.rows]


def _decode(raw: bytes) -> tuple[str, str]:
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        return raw.decode("utf-16"), "utf-16"
    for enc in ("utf-8-sig", "cp1252"):
        try:
            return raw.decode(enc), "utf-8" if enc == "utf-8-sig" else enc
        except UnicodeDecodeError:
            continue
    raise IngestError("INGEST_ENCODING_UNKNOWN", "Choose the encoding manually.")


def read_table(path, authorization: str, exclude_totals: bool = False, max_bytes: int = MAX_BYTES_DEFAULT) -> Table:
    p = Path(path)
    if not authorization.strip():
        raise IngestError("INGEST_NO_AUTHORIZATION", "Add an authorization note: 'Synthetic' or 'Authorized by ___ on ___'.")
    if p.suffix.lower() not in {".csv", ".txt", ".tsv"}:
        raise IngestError("INGEST_UNSUPPORTED_TYPE", "Export the file as CSV.")
    raw = p.read_bytes()
    if len(raw) > max_bytes:
        raise IngestError("INGEST_TOO_LARGE", f"File is {len(raw)/1048576:.1f} MB; the limit is {max_bytes/1048576:.0f} MB.")
    text, enc = _decode(raw)
    lines = [l for l in text.splitlines()[:30] if l.strip()]
    delim = max(",;\t|", key=lambda d: sum(len(l.split(d)) > 1 for l in lines))
    if not any(d in l for d in ",;\t|" for l in lines):
        delim = ","
    rows = [r for r in csv.reader(io.StringIO(text), delimiter=delim) if any(c.strip() for c in r)]
    if len(rows) < 2:
        raise IngestError("INGEST_EMPTY", "The file has no data rows.")
    mode = Counter(len(r) for r in rows[:30]).most_common(1)[0][0]
    h = next((i for i, r in enumerate(rows[:30]) if len(r) == mode and not any(parse_amount(c) is not None for c in r)), 0)
    headers = [c.strip() for c in rows[h]]
    body = rows[h + 1:]
    t = Table(p.name, str(p), hashlib.sha256(raw).hexdigest(), enc, delim, headers, body, authorization.strip())
    if h:
        t.warnings.append({"code": "HEADER_SKIPPED", "severity": "info", "count": h})
    if len(body) in EXCEL_LIMITS:
        t.warnings.append({"code": "INGEST_TRUNCATED", "severity": "blocking", "count": len(body)})
    if body and re.match(r"(?i)^\s*(grand\s+)?total", body[-1][0]):
        t.totals_row = body[-1]
        t.warnings.append({"code": "TOTALS_ROW", "severity": "caution", "count": 1})
        if exclude_totals:
            t.rows = body[:-1]
    ragged = sum(1 for r in t.rows if len(r) != len(headers))
    if t.rows and ragged / len(t.rows) > 0.005:
        t.warnings.append({"code": "INGEST_RAGGED_ROWS", "severity": "caution", "count": ragged})
    profile(t)
    return t


def _role(name: str, typ: str) -> tuple[str, float]:
    n = name.lower()
    if typ == "date":
        return "date", 0.9
    if typ == "number":
        return ("amount", 0.8) if re.search(r"amount|net|credit|debit|gross|total|revenue|price|value", n) else ("other", 0.4)
    if re.search(r"utr|ref|payout|invoice|order|txn|id$", n):
        return "key", 0.75
    if re.search(r"categ|type|channel|status|product|customer", n):
        return "category", 0.7
    return "other", 0.4


def profile(t: Table) -> None:
    t.columns = []
    seen, dups = set(), 0
    for r in t.rows:
        k = tuple(r)
        dups += k in seen
        seen.add(k)
    if dups:
        t.warnings.append({"code": "DUPLICATE_ROWS", "severity": "caution", "count": dups})
    for j, name in enumerate(t.headers):
        vals = [(r[j].strip() if j < len(r) else "") for r in t.rows]
        ne = [v for v in vals if v]
        nums = [parse_amount(v) for v in ne]
        dts = [parse_date(v) for v in ne]
        if ne and sum(d is not None for d in dts) / len(ne) >= 0.9:
            typ = "date"
        elif ne and sum(n is not None for n in nums) / len(ne) >= 0.9:
            typ = "number"
        else:
            typ = "text"
        c = Column(name, typ, len(vals) - len(ne), len(set(ne)))
        if typ == "number":
            good = [n for n in nums if n is not None]
            c.total, c.negatives = sum(good, Decimal(0)), sum(n < 0 for n in good)
        if typ == "date":
            good = [d for d in dts if d]
            c.min, c.max = min(good).isoformat(), max(good).isoformat()
        c.role, c.confidence = _role(name, typ)
        if vals and c.nulls / len(vals) > 0.2:
            t.warnings.append({"code": "HIGH_NULLS", "severity": "caution", "column": name, "count": c.nulls})
        if c.negatives:
            t.warnings.append({"code": "NEGATIVE_AMOUNTS", "severity": "info", "column": name, "count": c.negatives})
        if any(re.fullmatch(r"\d\.\d+[eE]\+\d+", v) for v in ne):
            t.warnings.append({"code": "SCIENTIFIC_NOTATION", "severity": "blocking", "column": name})
        t.columns.append(c)


def confirm(t: Table, roles: dict[str, str] | None = None) -> None:
    """User confirmation of roles. Blocking warnings must be acknowledged by the caller first."""
    for c in t.columns:
        if roles and c.name in roles:
            c.role = roles[c.name]
    t.confirmed = True
