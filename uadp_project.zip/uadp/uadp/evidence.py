"""Evidence package: a zip with a manifest whose hashes match the member files."""
from __future__ import annotations
import hashlib, json, zipfile
from pathlib import Path

README = ("This package was produced by UADP. manifest.json lists the SHA-256 of every file.\n"
          "To replay: re-run the same plan on the original files named in provenance.json and compare result.json hashes.\n")


def build_evidence(path, members: dict[str, str | bytes]) -> str:
    members = dict(members)
    members["README.txt"] = README
    data = {n: (v.encode() if isinstance(v, str) else v) for n, v in members.items()}
    manifest = {n: hashlib.sha256(b).hexdigest() for n, b in data.items()}
    mbytes = json.dumps(manifest, indent=1, sort_keys=True).encode()
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("manifest.json", mbytes)
        for n, b in data.items():
            z.writestr(n, b)
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_evidence(path) -> bool:
    with zipfile.ZipFile(path) as z:
        manifest = json.loads(z.read("manifest.json"))
        return all(hashlib.sha256(z.read(n)).hexdigest() == h for n, h in manifest.items()) and set(manifest) == set(z.namelist()) - {"manifest.json"}
