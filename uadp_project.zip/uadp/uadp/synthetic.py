"""Deterministic synthetic sample files (the only data used until gate RG-4)."""
from __future__ import annotations
import random
from decimal import Decimal
from pathlib import Path


def write_sample(folder) -> dict[str, Path]:
    d = Path(folder)
    d.mkdir(parents=True, exist_ok=True)
    rnd = random.Random(7)
    cats = ["Apparel", "Beauty", "Home", "Gadgets"]
    sales = ["order_id,order_date,customer,category,gross_amount"]
    for i in range(72):
        m, day = 4 + i // 12, 1 + rnd.randrange(27)
        sales.append(f'O{1001 + i},2026-{m:02d}-{day:02d},C{1 + rnd.randrange(12):02d},{cats[rnd.randrange(4)]},"{300 + rnd.randrange(9000):,}.{rnd.randrange(100):02d}"')
    pg, bank = ["payout_utr,settlement_date,net_amount"], ["bank_ref,value_date,credit"]
    for i in range(14):
        amt = Decimal(10000 + i * 137) + Decimal("0.25")
        key, dt = f"UTR{5000 + i}", f"2026-09-{3 + i:02d}"
        pg.append(f"{key},{dt},{amt}")
        if i == 2:
            bank += [f"{key},{dt},{amt - 3000}", f"{key},{dt},3000.00"]          # split settlement
        elif i == 3:
            bank.append(f"{key},{dt},{amt + 150}")                               # value difference
        elif i == 5:
            pass                                                                 # missing in bank
        elif i == 8:
            bank += [f"{key},{dt},{amt - 400}", f"{key},{dt},{amt + 400}"]       # ambiguous
        elif i == 10:
            bank.append(f"NEFT-X{i},2026-09-{4 + i:02d},{amt}")                   # no key; amount + date
        else:
            bank.append(f"{key},{dt},{amt}")
    bank.append("UTR9999,2026-09-20,1234.50")
    out = {}
    for name, lines in (("sales.csv", sales), ("pg.csv", pg), ("bank.csv", bank)):
        (d / name).write_text("\n".join(lines) + "\n", encoding="utf-8")
        out[name] = d / name
    return out
